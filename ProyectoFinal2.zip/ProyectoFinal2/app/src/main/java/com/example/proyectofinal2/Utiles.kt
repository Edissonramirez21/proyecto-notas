package com.example.proyectofinal2

import androidx.compose.ui.graphics.Color

object Utiles {
    val colores = listOf(
        Color(0xFFffffff),
        Color(0xFFff80ed),
        Color(0xFFff0000),
        Color(0xFFFFD700),
        Color(0xFFFFA500),
        Color(0xFFfa8072),
        Color(0xFF20b2aa),
        Color(0xFF00ff7f),
        Color(0xFFcc0000),
        Color(0xFFff7f50),
    )
}