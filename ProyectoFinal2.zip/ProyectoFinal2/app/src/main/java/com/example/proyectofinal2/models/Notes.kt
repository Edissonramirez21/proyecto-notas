package com.example.proyectofinal2.models

import com.google.firebase.Timestamp

class Notes (
    val userId:String = "",
    val title:String = "",
    val description: String = "",
    val timestamp: Timestamp = Timestamp.now(),
    val colorIndex: Int = 0,
    val documentId:String = "",
)